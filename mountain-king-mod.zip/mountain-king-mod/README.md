# Mountain King (Re della Montagna) — mod per NeoForge 1.21.1

Aggiunge due creature:

* **Re della Montagna** (`mountainking:mountain_king`) — colosso di ~4,3 blocchi: due gambe tozze, busto emaciato e ricurvo,
  quattro braccia (due lunghe con artigli ossei, due corte con dita quasi umane), pelo grigio-giallastro,
  cinque occhi bianco latte, bocca semiaperta piena di denti, bava che cola dal mento e "vermi" che si muovono sotto la pelle.
* **Larva del Re della Montagna** (`mountainking:larva`) — la sua versione in miniatura.

## Come funziona in gioco

| Cosa | Comportamento |
|---|---|
| **Cieco** | Non usa mai la vista: sceglie i bersagli solo in base ai rumori. |
| **Rumore** | Corsa (~26 blocchi), camminata (~14), salto (~20), colpi/scavo/piazzare blocchi (~14), mangiare/tendere l'arco (~7), subire danno (~32). **Di soppiatto (shift) = silenzio.** |
| **Contatto** | A meno di 3 blocchi sente chiunque, anche chi sta fermo. |
| **Campana** | Una campana che suona (anche con redstone o con una freccia) lo attira da lontano. Quando arriva resta **confuso** (12 s di default) e ignora chi non gli e' vicinissimo. |
| **Pelo folto** | Le frecce fanno il 20% del danno, le spade il 50%. Il **fuoco** invece gli fa il 160% del danno. |
| **Artigli e mani** | I colpi fanno molto danno e le mani quasi umane afferrano la preda (Lentezza III per 4 s). |
| **Trasformazione** | Se il Re uccide un giocatore, il cadavere diventa una **Larva dormiente** (giace a terra e si contorce). |
| **Larva dormiente** | Dopo 30 s (o se qualcuno si avvicina a meno di 2,5 blocchi, o se viene ferita e sopravvive) si risveglia e va a caccia degli altri giocatori. Mentre dorme subisce il doppio dei danni. |
| **Spawn** | Rarissimo nei biomi montani (modificabile in `data/mountainking/neoforge/biome_modifier/`). In creativa: uova generatrici nella scheda "Re della Montagna". |

Comandi utili: `/summon mountainking:mountain_king` e `/summon mountainking:larva`.

**Nota per i test:** di default il Re ignora i giocatori in creativa. Per provarlo in creativa metti
`targetCreativePlayers = true` in `config/mountainking-common.toml` (si crea al primo avvio).

## Come compilarla

Servono **Java 21** e una connessione a internet (la prima volta Gradle scarica Minecraft e NeoForge).

**Metodo piu' semplice — IntelliJ IDEA (la Community va bene):**
1. `File > Open` e scegli questa cartella. IntelliJ legge `gradle/wrapper/gradle-wrapper.properties`, scarica Gradle e sincronizza da solo.
2. A destra apri **Gradle > Tasks > build > build** (doppio clic): il file `.jar` finisce in `build/libs/mountainking-1.0.0.jar`.
3. Per provarla subito: **Gradle > Tasks > neoforge > runClient** (apre Minecraft con la mod gia' dentro).

**Da riga di comando:** manca il file `gradle-wrapper.jar` (e' un binario che non posso includere). Hai due strade:
* scarica l'MDK ufficiale 1.21.1 (https://github.com/NeoForgeMDKs/MDK-1.21.1-ModDevGradle → *Code > Download ZIP*) e copia in questa cartella
  `gradlew`, `gradlew.bat` e la cartella `gradle/`; poi `./gradlew build` (Windows: `gradlew.bat build`);
* oppure, se hai Gradle installato, `gradle wrapper` una volta sola.

**Per usarla:** copia `mountainking-1.0.0.jar` nella cartella `mods/` di un'istanza **Minecraft 1.21.1 + NeoForge 21.1.x**
(va installata anche sul server, se giochi in multiplayer).

## Opzioni (`config/mountainking-common.toml`)

`hearingRange`, `bellRange`, `confusionSeconds`, `targetCreativePlayers`, `transformKilledPlayers`, `larvaDormantSeconds`.

## Struttura del codice

* `entity/MountainKingEntity.java` — udito, campana/confusione, difese, attacco (e' il file piu' interessante da modificare).
* `entity/LarvaEntity.java` — dormiente → risveglio → caccia.
* `GameEvents.java` — trasformazione del giocatore ucciso in Larva.
* `client/MountainKingModel.java` — modello 3D e animazioni; `client/*Renderer`, `*Layer` — rendering, occhi luminosi e vermi.
* `registry/` — registrazione di entita', oggetti e scheda creativa. `Config.java` — opzioni.
* `src/main/resources` — texture (generate proceduralmente, ridisegnale quando vuoi), lingue it/en, loot table, spawn.

## Limiti noti (leggere!)

* Il codice e' stato scritto **senza poterlo compilare ne' avviarlo in Minecraft**: la struttura e le versioni di Gradle/NeoForge sono
  quelle dell'MDK ufficiale 1.21.1, ma se Gradle segnala un errore di compilazione e' probabilmente un nome di metodo da correggere di una riga.
* I suoni sono presi in prestito dal Warden, dal Ravager e dal Silverfish (nessun file audio nuovo).
* Texture e modello sono "programmer art" generata da script: funzionano, ma un artista (o Blockbench) li migliorerebbe molto.

## Compilare da telefono con GitHub

1. Crea un repository su github.com e carica lo zip intero (senza estrarlo) con **Add file > Upload files**.
2. Aggiungi il file del workflow come `.github/workflows/build.yml` (te lo fornisce chi ti ha dato la mod).
3. Tab **Actions**: la build parte da sola; il `.jar` finale compare in **Releases**.
4. Se la build fallisce, nella pagina della run c'e' la sezione **Errori di compilazione**: uno screenshot di quella sezione basta per correggere.
