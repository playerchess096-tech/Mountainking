package com.example.mountainking.client;

import com.example.mountainking.MountainKingMod;
import com.example.mountainking.registry.ModEntities;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;

/** Registrazione di modelli e renderer: esiste solo sul client. */
@EventBusSubscriber(modid = MountainKingMod.MODID, bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientSetup {

    @SubscribeEvent
    public static void registerLayers(EntityRenderersEvent.RegisterLayerDefinitions event) {
        event.registerLayerDefinition(MountainKingModel.LAYER_LOCATION, MountainKingModel::createBodyLayer);
    }

    @SubscribeEvent
    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModEntities.MOUNTAIN_KING.get(), MountainKingRenderer::new);
        event.registerEntityRenderer(ModEntities.LARVA.get(), LarvaRenderer::new);
    }
}
