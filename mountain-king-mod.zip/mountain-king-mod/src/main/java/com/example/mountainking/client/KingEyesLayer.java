package com.example.mountainking.client;

import com.example.mountainking.MountainKingMod;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.EyesLayer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Mob;

/** I cinque occhi bianchi come il latte: si vedono (leggermente luminosi) anche al buio. */
public class KingEyesLayer<T extends Mob, M extends EntityModel<T>> extends EyesLayer<T, M> {

    private static final RenderType EYES = RenderType.eyes(
            ResourceLocation.fromNamespaceAndPath(MountainKingMod.MODID, "textures/entity/mountain_king_eyes.png"));

    public KingEyesLayer(RenderLayerParent<T, M> parent) {
        super(parent);
    }

    @Override
    public RenderType renderType() {
        return EYES;
    }
}
