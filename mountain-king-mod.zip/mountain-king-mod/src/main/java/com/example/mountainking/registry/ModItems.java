package com.example.mountainking.registry;

import com.example.mountainking.MountainKingMod;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.common.DeferredSpawnEggItem;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModItems {
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(MountainKingMod.MODID);
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MountainKingMod.MODID);

    public static final DeferredHolder<Item, Item> KING_CLAW =
            ITEMS.register("king_claw", () -> new Item(new Item.Properties().stacksTo(16)));
    public static final DeferredHolder<Item, Item> KING_FUR =
            ITEMS.register("king_fur", () -> new Item(new Item.Properties()));

    public static final DeferredHolder<Item, DeferredSpawnEggItem> MOUNTAIN_KING_SPAWN_EGG =
            ITEMS.register("mountain_king_spawn_egg", () -> new DeferredSpawnEggItem(
                    ModEntities.MOUNTAIN_KING, 0x8C8466, 0xEDEBDD, new Item.Properties()));
    public static final DeferredHolder<Item, DeferredSpawnEggItem> LARVA_SPAWN_EGG =
            ITEMS.register("larva_spawn_egg", () -> new DeferredSpawnEggItem(
                    ModEntities.LARVA, 0x6E684F, 0xB0A878, new Item.Properties()));

    public static final DeferredHolder<CreativeModeTab, CreativeModeTab> MAIN_TAB =
            TABS.register("main", () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.mountainking"))
                    .icon(() -> new ItemStack(KING_CLAW.get()))
                    .displayItems((parameters, output) -> {
                        output.accept(MOUNTAIN_KING_SPAWN_EGG.get());
                        output.accept(LARVA_SPAWN_EGG.get());
                        output.accept(KING_CLAW.get());
                        output.accept(KING_FUR.get());
                    })
                    .build());
}
