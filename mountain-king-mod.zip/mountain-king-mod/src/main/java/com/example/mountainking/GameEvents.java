package com.example.mountainking;

import com.example.mountainking.entity.LarvaEntity;
import com.example.mountainking.entity.MountainKingEntity;
import com.example.mountainking.registry.ModEntities;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.living.LivingDeathEvent;

/** Eventi di gioco: qui avviene la trasformazione del giocatore ucciso in Larva. */
@EventBusSubscriber(modid = MountainKingMod.MODID)
public class GameEvents {

    @SubscribeEvent
    public static void onLivingDeath(LivingDeathEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) {
            return;
        }
        if (!Config.TRANSFORM_PLAYERS.get()) {
            return;
        }
        // solo se l'ha ucciso il Re della Montagna in persona
        if (!(event.getSource().getEntity() instanceof MountainKingEntity)) {
            return;
        }
        if (!(player.level() instanceof ServerLevel level)) {
            return;
        }

        LarvaEntity larva = ModEntities.LARVA.get().create(level);
        if (larva == null) {
            return;
        }
        larva.moveTo(player.getX(), player.getY(), player.getZ(), player.getYRot(), 0.0F);
        larva.startDormant(Config.LARVA_DORMANT_SECONDS.get() * 20, player.getName().getString());
        level.addFreshEntity(larva);

        level.playSound(null, player.blockPosition(), SoundEvents.ZOMBIE_INFECT, SoundSource.HOSTILE, 1.5F, 0.5F);
        level.getServer().getPlayerList().broadcastSystemMessage(
                Component.translatable("message.mountainking.transformed", player.getDisplayName()), false);
    }
}
