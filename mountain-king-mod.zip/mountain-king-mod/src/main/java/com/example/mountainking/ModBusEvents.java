package com.example.mountainking;

import com.example.mountainking.entity.LarvaEntity;
import com.example.mountainking.entity.MountainKingEntity;
import com.example.mountainking.registry.ModEntities;
import net.minecraft.world.entity.SpawnPlacementTypes;
import net.minecraft.world.level.levelgen.Heightmap;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;
import net.neoforged.neoforge.event.entity.RegisterSpawnPlacementsEvent;

/** Eventi sul bus della mod: attributi delle creature e regole di spawn. */
@EventBusSubscriber(modid = MountainKingMod.MODID, bus = EventBusSubscriber.Bus.MOD)
public class ModBusEvents {

    @SubscribeEvent
    public static void registerAttributes(EntityAttributeCreationEvent event) {
        event.put(ModEntities.MOUNTAIN_KING.get(), MountainKingEntity.createAttributes().build());
        event.put(ModEntities.LARVA.get(), LarvaEntity.createAttributes().build());
    }

    @SubscribeEvent
    public static void registerSpawnPlacements(RegisterSpawnPlacementsEvent event) {
        event.register(ModEntities.MOUNTAIN_KING.get(), SpawnPlacementTypes.ON_GROUND,
                Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, MountainKingEntity::checkKingSpawnRules,
                RegisterSpawnPlacementsEvent.Operation.OR);
    }
}
