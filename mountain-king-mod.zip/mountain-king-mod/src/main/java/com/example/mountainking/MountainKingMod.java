package com.example.mountainking;

import com.example.mountainking.registry.ModEntities;
import com.example.mountainking.registry.ModItems;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.config.ModConfig;

/**
 * Mod "Mountain King" (Re della Montagna) per NeoForge 1.21.1.
 * Aggiunge il Re della Montagna (cieco, caccia seguendo i rumori) e la Larva del Re della Montagna.
 */
@Mod(MountainKingMod.MODID)
public class MountainKingMod {
    /** Deve coincidere con mod_id in gradle.properties. */
    public static final String MODID = "mountainking";

    public MountainKingMod(IEventBus modEventBus, ModContainer modContainer) {
        ModEntities.ENTITIES.register(modEventBus);
        ModItems.ITEMS.register(modEventBus);
        ModItems.TABS.register(modEventBus);
        modContainer.registerConfig(ModConfig.Type.COMMON, Config.SPEC);
    }
}
