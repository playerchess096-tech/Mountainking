package com.example.mountainking.client;

import com.example.mountainking.MountainKingMod;
import com.example.mountainking.entity.LarvaEntity;
import com.example.mountainking.entity.MountainKingEntity;
import net.minecraft.client.model.HierarchicalModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.monster.Monster;

/**
 * Modello 3D del Re della Montagna: due gambe tozze, busto emaciato e ricurvo, quattro braccia
 * (due lunghe con artigli ossei, due corte con dita quasi umane), testa con cinque occhi e mascella aperta.
 * La Larva usa lo stesso modello, ridotto in scala dal renderer.
 *
 * ATTENZIONE: il metodo createBodyLayer() e' generato da uno script; per modifiche grandi
 * conviene rigenerarlo (o ridisegnare il modello con Blockbench).
 */
public class MountainKingModel<T extends Monster> extends HierarchicalModel<T> {

    public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(
            ResourceLocation.fromNamespaceAndPath(MountainKingMod.MODID, "mountain_king"), "main");

    private static final float PI = (float) Math.PI;
    private static final float DEG = PI / 180.0F;

    // pose a riposo (uguali a quelle usate in createBodyLayer)
    private static final float TORSO_REST = 0.35F;
    private static final float HEAD_REST = -0.55F;
    private static final float JAW_REST = 0.6F;
    private static final float ARM_REST_X = -0.25F;
    private static final float ARM_REST_Z = 0.12F;
    private static final float FORE_REST_X = -0.3F;
    private static final float CLAW_REST_X = -0.35F;
    private static final float SARM_REST_X = -0.9F;
    private static final float SARM_REST_Z = 0.1F;
    private static final float SFORE_REST_X = -0.8F;
    private static final float FINGER_REST_X = -0.3F;

    private final ModelPart root;
    private final ModelPart king;
    private final ModelPart legR;
    private final ModelPart legL;
    private final ModelPart torso;
    private final ModelPart head;
    private final ModelPart jaw;
    private final ModelPart armR;
    private final ModelPart armL;
    private final ModelPart foreR;
    private final ModelPart foreL;
    private final ModelPart clawsR;
    private final ModelPart clawsL;
    private final ModelPart sArmR;
    private final ModelPart sArmL;
    private final ModelPart sForeR;
    private final ModelPart sForeL;
    private final ModelPart fingersR;
    private final ModelPart fingersL;

    public MountainKingModel(ModelPart root) {
        this.root = root;
        this.king = root.getChild("king");
        this.legR = this.king.getChild("leg_r");
        this.legL = this.king.getChild("leg_l");
        this.torso = this.king.getChild("torso");
        this.head = this.torso.getChild("head");
        this.jaw = this.head.getChild("jaw");
        this.armR = this.torso.getChild("arm_r");
        this.armL = this.torso.getChild("arm_l");
        this.foreR = this.armR.getChild("forearm_r");
        this.foreL = this.armL.getChild("forearm_l");
        this.clawsR = this.foreR.getChild("claws_r");
        this.clawsL = this.foreL.getChild("claws_l");
        this.sArmR = this.torso.getChild("shortarm_r");
        this.sArmL = this.torso.getChild("shortarm_l");
        this.sForeR = this.sArmR.getChild("shortfore_r");
        this.sForeL = this.sArmL.getChild("shortfore_l");
        this.fingersR = this.sForeR.getChild("fingers_r");
        this.fingersL = this.sForeL.getChild("fingers_l");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition king = root.addOrReplaceChild("king", CubeListBuilder.create(),
                PartPose.offset(0.0F, 24.0F, 0.0F));
        PartDefinition legR = king.addOrReplaceChild("leg_r", CubeListBuilder.create()
                .texOffs(24, 40).addBox(-5.5F, 0.0F, -5.5F, 11.0F, 13.0F, 11.0F)
                .texOffs(0, 66).addBox(-6.0F, 13.0F, -10.0F, 12.0F, 4.0F, 16.0F)
                .texOffs(52, 119).addBox(-5.5F, 14.0F, -13.0F, 3.0F, 3.0F, 3.0F)
                .texOffs(52, 119).addBox(-1.5F, 14.0F, -13.0F, 3.0F, 3.0F, 3.0F)
                .texOffs(52, 119).addBox(2.5F, 14.0F, -13.0F, 3.0F, 3.0F, 3.0F),
                PartPose.offset(-9.0F, -17.0F, 1.0F));
        PartDefinition legL = king.addOrReplaceChild("leg_l", CubeListBuilder.create()
                .texOffs(24, 40).addBox(-5.5F, 0.0F, -5.5F, 11.0F, 13.0F, 11.0F)
                .texOffs(0, 66).addBox(-6.0F, 13.0F, -10.0F, 12.0F, 4.0F, 16.0F)
                .texOffs(52, 119).addBox(-5.5F, 14.0F, -13.0F, 3.0F, 3.0F, 3.0F)
                .texOffs(52, 119).addBox(-1.5F, 14.0F, -13.0F, 3.0F, 3.0F, 3.0F)
                .texOffs(52, 119).addBox(2.5F, 14.0F, -13.0F, 3.0F, 3.0F, 3.0F),
                PartPose.offset(9.0F, -17.0F, 1.0F));
        PartDefinition torso = king.addOrReplaceChild("torso", CubeListBuilder.create()
                .texOffs(68, 40).addBox(-8.0F, -9.0F, -5.0F, 16.0F, 11.0F, 10.0F)
                .texOffs(0, 0).addBox(-7.0F, -40.0F, -4.0F, 14.0F, 32.0F, 8.0F)
                .texOffs(44, 105).addBox(-4.0F, -44.0F, -4.0F, 8.0F, 5.0F, 8.0F)
                .texOffs(72, 119).addBox(-6.0F, -34.0F, -5.0F, 12.0F, 2.0F, 1.0F)
                .texOffs(72, 119).addBox(-6.0F, -30.0F, -5.0F, 12.0F, 2.0F, 1.0F)
                .texOffs(72, 119).addBox(-6.0F, -26.0F, -5.0F, 12.0F, 2.0F, 1.0F)
                .texOffs(0, 86).addBox(-12.0F, -41.0F, -5.0F, 24.0F, 9.0F, 10.0F)
                .texOffs(56, 66).addBox(-7.0F, -47.0F, 1.0F, 14.0F, 12.0F, 8.0F)
                .texOffs(76, 105).addBox(12.0F, -45.0F, -3.0F, 5.0F, 7.0F, 6.0F)
                .texOffs(76, 105).addBox(-17.0F, -45.0F, -3.0F, 5.0F, 7.0F, 6.0F)
                .texOffs(98, 105).addBox(-3.0F, -52.0F, 4.0F, 6.0F, 6.0F, 5.0F),
                PartPose.offsetAndRotation(0.0F, -17.0F, 3.0F, 0.35F, 0.0F, 0.0F));
        PartDefinition head = torso.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(44, 0).addBox(-6.0F, -15.0F, -9.0F, 12.0F, 15.0F, 13.0F)
                .texOffs(0, 119).addBox(-7.0F, -14.0F, -10.0F, 14.0F, 3.0F, 3.0F)
                .texOffs(68, 119).addBox(-5.0F, 0.0F, -9.0F, 1.0F, 4.0F, 1.0F)
                .texOffs(68, 119).addBox(-3.0F, 0.0F, -9.0F, 1.0F, 4.0F, 1.0F)
                .texOffs(68, 119).addBox(-1.0F, 0.0F, -9.0F, 1.0F, 4.0F, 1.0F)
                .texOffs(68, 119).addBox(1.0F, 0.0F, -9.0F, 1.0F, 4.0F, 1.0F)
                .texOffs(68, 119).addBox(3.0F, 0.0F, -9.0F, 1.0F, 4.0F, 1.0F)
                .texOffs(68, 119).addBox(5.0F, 0.0F, -9.0F, 1.0F, 4.0F, 1.0F),
                PartPose.offsetAndRotation(0.0F, -41.0F, -2.0F, -0.55F, 0.0F, 0.0F));
        PartDefinition jaw = head.addOrReplaceChild("jaw", CubeListBuilder.create()
                .texOffs(68, 86).addBox(-5.0F, 0.0F, -11.0F, 10.0F, 4.0F, 12.0F)
                .texOffs(68, 119).addBox(-4.0F, -4.0F, -10.0F, 1.0F, 4.0F, 1.0F)
                .texOffs(68, 119).addBox(-2.0F, -4.0F, -10.0F, 1.0F, 4.0F, 1.0F)
                .texOffs(68, 119).addBox(0.0F, -4.0F, -10.0F, 1.0F, 4.0F, 1.0F)
                .texOffs(68, 119).addBox(2.0F, -4.0F, -10.0F, 1.0F, 4.0F, 1.0F)
                .texOffs(68, 119).addBox(4.0F, -4.0F, -10.0F, 1.0F, 4.0F, 1.0F),
                PartPose.offsetAndRotation(0.0F, -2.0F, 2.0F, 0.6F, 0.0F, 0.0F));
        PartDefinition armR = torso.addOrReplaceChild("arm_r", CubeListBuilder.create()
                .texOffs(94, 0).addBox(-3.5F, -3.0F, -3.5F, 7.0F, 20.0F, 7.0F),
                PartPose.offsetAndRotation(-15.0F, -37.0F, 0.0F, -0.25F, 0.0F, 0.12F));
        PartDefinition forearmR = armR.addOrReplaceChild("forearm_r", CubeListBuilder.create()
                .texOffs(0, 40).addBox(-3.0F, 0.0F, -3.0F, 6.0F, 20.0F, 6.0F)
                .texOffs(0, 105).addBox(-4.0F, 20.0F, -4.0F, 8.0F, 6.0F, 8.0F),
                PartPose.offsetAndRotation(0.0F, 17.0F, 0.0F, -0.3F, 0.0F, 0.0F));
        PartDefinition clawsR = forearmR.addOrReplaceChild("claws_r", CubeListBuilder.create()
                .texOffs(120, 105).addBox(-4.0F, 0.0F, -1.0F, 2.0F, 9.0F, 2.0F)
                .texOffs(120, 105).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 9.0F, 2.0F)
                .texOffs(120, 105).addBox(2.0F, 0.0F, -1.0F, 2.0F, 9.0F, 2.0F),
                PartPose.offsetAndRotation(0.0F, 26.0F, 0.0F, -0.35F, 0.0F, 0.0F));
        PartDefinition armL = torso.addOrReplaceChild("arm_l", CubeListBuilder.create()
                .texOffs(94, 0).addBox(-3.5F, -3.0F, -3.5F, 7.0F, 20.0F, 7.0F),
                PartPose.offsetAndRotation(15.0F, -37.0F, 0.0F, -0.25F, 0.0F, -0.12F));
        PartDefinition forearmL = armL.addOrReplaceChild("forearm_l", CubeListBuilder.create()
                .texOffs(0, 40).addBox(-3.0F, 0.0F, -3.0F, 6.0F, 20.0F, 6.0F)
                .texOffs(0, 105).addBox(-4.0F, 20.0F, -4.0F, 8.0F, 6.0F, 8.0F),
                PartPose.offsetAndRotation(0.0F, 17.0F, 0.0F, -0.3F, 0.0F, 0.0F));
        PartDefinition clawsL = forearmL.addOrReplaceChild("claws_l", CubeListBuilder.create()
                .texOffs(120, 105).addBox(-4.0F, 0.0F, -1.0F, 2.0F, 9.0F, 2.0F)
                .texOffs(120, 105).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 9.0F, 2.0F)
                .texOffs(120, 105).addBox(2.0F, 0.0F, -1.0F, 2.0F, 9.0F, 2.0F),
                PartPose.offsetAndRotation(0.0F, 26.0F, 0.0F, -0.35F, 0.0F, 0.0F));
        PartDefinition shortarmR = torso.addOrReplaceChild("shortarm_r", CubeListBuilder.create()
                .texOffs(112, 86).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 11.0F, 4.0F),
                PartPose.offsetAndRotation(-9.0F, -22.0F, -3.0F, -0.9F, 0.0F, 0.1F));
        PartDefinition shortforeR = shortarmR.addOrReplaceChild("shortfore_r", CubeListBuilder.create()
                .texOffs(32, 105).addBox(-1.5F, 0.0F, -1.5F, 3.0F, 11.0F, 3.0F)
                .texOffs(34, 119).addBox(-3.0F, 11.0F, -1.5F, 6.0F, 3.0F, 3.0F),
                PartPose.offsetAndRotation(0.0F, 11.0F, 0.0F, -0.8F, 0.0F, 0.0F));
        PartDefinition fingersR = shortforeR.addOrReplaceChild("fingers_r", CubeListBuilder.create()
                .texOffs(64, 119).addBox(-3.0F, 0.0F, -0.5F, 1.0F, 5.0F, 1.0F)
                .texOffs(64, 119).addBox(-1.5F, 0.0F, -0.5F, 1.0F, 5.0F, 1.0F)
                .texOffs(64, 119).addBox(0.0F, 0.0F, -0.5F, 1.0F, 5.0F, 1.0F)
                .texOffs(64, 119).addBox(1.5F, 0.0F, -0.5F, 1.0F, 5.0F, 1.0F),
                PartPose.offsetAndRotation(0.0F, 14.0F, 0.0F, -0.3F, 0.0F, 0.0F));
        PartDefinition shortarmL = torso.addOrReplaceChild("shortarm_l", CubeListBuilder.create()
                .texOffs(112, 86).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 11.0F, 4.0F),
                PartPose.offsetAndRotation(9.0F, -22.0F, -3.0F, -0.9F, 0.0F, -0.1F));
        PartDefinition shortforeL = shortarmL.addOrReplaceChild("shortfore_l", CubeListBuilder.create()
                .texOffs(32, 105).addBox(-1.5F, 0.0F, -1.5F, 3.0F, 11.0F, 3.0F)
                .texOffs(34, 119).addBox(-3.0F, 11.0F, -1.5F, 6.0F, 3.0F, 3.0F),
                PartPose.offsetAndRotation(0.0F, 11.0F, 0.0F, -0.8F, 0.0F, 0.0F));
        PartDefinition fingersL = shortforeL.addOrReplaceChild("fingers_l", CubeListBuilder.create()
                .texOffs(64, 119).addBox(-3.0F, 0.0F, -0.5F, 1.0F, 5.0F, 1.0F)
                .texOffs(64, 119).addBox(-1.5F, 0.0F, -0.5F, 1.0F, 5.0F, 1.0F)
                .texOffs(64, 119).addBox(0.0F, 0.0F, -0.5F, 1.0F, 5.0F, 1.0F)
                .texOffs(64, 119).addBox(1.5F, 0.0F, -0.5F, 1.0F, 5.0F, 1.0F),
                PartPose.offsetAndRotation(0.0F, 14.0F, 0.0F, -0.3F, 0.0F, 0.0F));
        return LayerDefinition.create(mesh, 128, 128);
    }

    @Override
    public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks,
                          float netHeadYaw, float headPitch) {
        final boolean dormant = entity instanceof LarvaEntity larva && larva.isDormant();
        final boolean confused = entity instanceof MountainKingEntity k && k.isConfused();

        if (dormant) {
            this.poseDormant(ageInTicks);
            return;
        }

        this.king.xRot = 0.0F;
        this.king.zRot = 0.0F;
        this.king.y = 24.0F;

        final float swing = limbSwing * 0.45F;                       // andatura lenta e pesante
        final float amt = Math.min(limbSwingAmount * 1.4F, 1.0F);
        final float idle = Mth.sin(ageInTicks * 0.05F) * 0.04F;      // respiro

        // gambe
        this.legR.xRot = Mth.cos(swing) * amt;
        this.legL.xRot = Mth.cos(swing + PI) * amt;

        // busto ricurvo che ondeggia
        this.torso.xRot = TORSO_REST + Mth.cos(swing * 2.0F) * 0.05F * amt + idle * 0.4F;
        this.torso.zRot = Mth.cos(swing) * 0.05F * amt;

        // testa: e' cieco, la gira continuamente come se ascoltasse (molto di piu' quando e' confuso)
        final float sway = confused ? 0.6F : 0.12F;
        this.head.xRot = HEAD_REST + headPitch * DEG * 0.35F + Mth.cos(ageInTicks * 0.06F) * 0.05F;
        this.head.yRot = netHeadYaw * DEG * 0.5F + Mth.sin(ageInTicks * 0.045F) * sway;
        this.head.zRot = Mth.sin(ageInTicks * 0.032F) * (confused ? 0.3F : 0.05F);

        // mascella semiaperta
        final boolean aggressive = entity.isAggressive();
        this.jaw.xRot = JAW_REST + Mth.sin(ageInTicks * 0.13F) * 0.07F + (aggressive ? 0.25F : 0.0F);

        // braccia lunghe: pendono quasi fino a terra e oscillano in controfase rispetto alle gambe
        final float armSwing = Mth.cos(swing) * 0.8F * amt;
        this.armR.xRot = ARM_REST_X - armSwing + idle;
        this.armL.xRot = ARM_REST_X + armSwing - idle;
        this.armR.zRot = ARM_REST_Z;
        this.armL.zRot = -ARM_REST_Z;
        this.foreR.xRot = FORE_REST_X + idle;
        this.foreL.xRot = FORE_REST_X - idle;
        this.clawsR.xRot = CLAW_REST_X;
        this.clawsL.xRot = CLAW_REST_X;

        // braccia corte: strette al petto, le dita fremono
        this.sArmR.xRot = SARM_REST_X + Mth.sin(ageInTicks * 0.09F) * 0.06F - (aggressive ? 0.4F : 0.0F);
        this.sArmL.xRot = SARM_REST_X + Mth.sin(ageInTicks * 0.09F + 1.5F) * 0.06F - (aggressive ? 0.4F : 0.0F);
        this.sArmR.zRot = SARM_REST_Z;
        this.sArmL.zRot = -SARM_REST_Z;
        this.sForeR.xRot = SFORE_REST_X;
        this.sForeL.xRot = SFORE_REST_X;
        this.fingersR.xRot = FINGER_REST_X + Mth.sin(ageInTicks * 0.31F) * 0.25F;
        this.fingersL.xRot = FINGER_REST_X + Mth.sin(ageInTicks * 0.29F + 1.0F) * 0.25F;

        // attacco: le braccia lunghe si alzano e calano di colpo
        final float attack = entity.getAttackAnim(ageInTicks - entity.tickCount);
        if (attack > 0.0F) {
            final float s = Mth.sin(attack * PI);
            this.armR.xRot -= 2.2F * s;
            this.armL.xRot -= 2.2F * s;
            this.foreR.xRot -= 0.6F * s;
            this.foreL.xRot -= 0.6F * s;
            this.sArmR.xRot -= 0.5F * s;
            this.sArmL.xRot -= 0.5F * s;
            this.torso.xRot += 0.35F * s;
        }
    }

    /** Posa della Larva "dormiente": il cadavere trasformato giace sulla schiena e si contorce. */
    private void poseDormant(float age) {
        this.king.xRot = -PI / 2.0F;
        this.king.y = 24.0F - 9.0F;
        this.king.zRot = Mth.sin(age * 0.31F) * 0.05F;

        this.legR.xRot = 0.15F + Mth.sin(age * 0.23F) * 0.08F;
        this.legL.xRot = -0.1F + Mth.sin(age * 0.19F + 1.0F) * 0.08F;
        this.torso.xRot = Mth.sin(age * 0.11F) * 0.04F;
        this.torso.zRot = Mth.sin(age * 0.27F) * 0.05F;

        this.head.xRot = -0.3F + Mth.sin(age * 0.17F) * 0.1F;
        this.head.yRot = Mth.sin(age * 0.13F) * 0.3F;
        this.head.zRot = Mth.sin(age * 0.21F) * 0.1F;
        this.jaw.xRot = 0.3F + (Mth.sin(age * 0.5F) + 1.0F) * 0.12F;

        this.armR.xRot = -0.1F + Mth.sin(age * 0.2F) * 0.12F;
        this.armR.zRot = 0.55F;
        this.armL.xRot = -0.1F + Mth.sin(age * 0.2F + 2.0F) * 0.12F;
        this.armL.zRot = -0.55F;
        this.foreR.xRot = FORE_REST_X;
        this.foreL.xRot = FORE_REST_X;
        this.clawsR.xRot = CLAW_REST_X;
        this.clawsL.xRot = CLAW_REST_X;

        this.sArmR.xRot = -0.5F + Mth.sin(age * 0.33F) * 0.15F;
        this.sArmL.xRot = -0.5F + Mth.sin(age * 0.33F + 1.0F) * 0.15F;
        this.sArmR.zRot = SARM_REST_Z;
        this.sArmL.zRot = -SARM_REST_Z;
        this.sForeR.xRot = SFORE_REST_X;
        this.sForeL.xRot = SFORE_REST_X;
        this.fingersR.xRot = FINGER_REST_X + Mth.sin(age * 0.6F) * 0.35F;
        this.fingersL.xRot = FINGER_REST_X + Mth.sin(age * 0.55F + 1.0F) * 0.35F;
    }

    @Override
    public ModelPart root() {
        return this.root;
    }
}
