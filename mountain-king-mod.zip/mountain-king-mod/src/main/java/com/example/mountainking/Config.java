package com.example.mountainking;

import net.neoforged.neoforge.common.ModConfigSpec;

/** Opzioni modificabili in config/mountainking-common.toml (si creano al primo avvio). */
public class Config {
    private static final ModConfigSpec.Builder BUILDER = new ModConfigSpec.Builder();

    public static final ModConfigSpec.IntValue HEARING_RANGE = BUILDER
            .comment("Distanza massima (in blocchi) a cui il Re puo' sentire un giocatore che corre.")
            .defineInRange("hearingRange", 32, 8, 96);

    public static final ModConfigSpec.IntValue BELL_RANGE = BUILDER
            .comment("Distanza massima (in blocchi) a cui il Re sente suonare una campana.")
            .defineInRange("bellRange", 48, 8, 128);

    public static final ModConfigSpec.IntValue CONFUSION_SECONDS = BUILDER
            .comment("Per quanti secondi il Re resta confuso dopo aver raggiunto una campana.")
            .defineInRange("confusionSeconds", 12, 1, 120);

    public static final ModConfigSpec.BooleanValue TARGET_CREATIVE = BUILDER
            .comment("Se true il Re sente anche i giocatori in creativa (utile per fare dei test).")
            .define("targetCreativePlayers", false);

    public static final ModConfigSpec.BooleanValue TRANSFORM_PLAYERS = BUILDER
            .comment("Se true i giocatori uccisi dal Re diventano una Larva dormiente.")
            .define("transformKilledPlayers", true);

    public static final ModConfigSpec.IntValue LARVA_DORMANT_SECONDS = BUILDER
            .comment("Secondi di 'sonno' della Larva prima che si risvegli e cominci la caccia.")
            .defineInRange("larvaDormantSeconds", 30, 3, 600);

    public static final ModConfigSpec SPEC = BUILDER.build();
}
