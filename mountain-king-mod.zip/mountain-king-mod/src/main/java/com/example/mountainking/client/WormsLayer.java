package com.example.mountainking.client;

import com.example.mountainking.MountainKingMod;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Mob;

/**
 * Le "forme simili a vermi" che si muovono sotto la pelle: ridisegna il modello con una texture
 * semi-trasparente che scorre lentamente (stesso trucco del Creeper carico), cosi' sembra che qualcosa
 * strisci sotto il pelo.
 */
public class WormsLayer<T extends Mob, M extends EntityModel<T>> extends RenderLayer<T, M> {

    private static final ResourceLocation WORMS =
            ResourceLocation.fromNamespaceAndPath(MountainKingMod.MODID, "textures/entity/mountain_king_worms.png");

    public WormsLayer(RenderLayerParent<T, M> parent) {
        super(parent);
    }

    @Override
    public void render(PoseStack poseStack, MultiBufferSource buffer, int packedLight, T entity,
                       float limbSwing, float limbSwingAmount, float partialTick, float ageInTicks,
                       float netHeadYaw, float headPitch) {
        final float u = (ageInTicks * 0.004F + Mth.sin(ageInTicks * 0.05F) * 0.01F) % 1.0F;
        final float v = (ageInTicks * 0.011F) % 1.0F;
        final VertexConsumer consumer = buffer.getBuffer(RenderType.energySwirl(WORMS, u, v));
        this.getParentModel().renderToBuffer(poseStack, consumer, packedLight, OverlayTexture.NO_OVERLAY, 0xFFC0C0C0);
    }
}
