package com.example.mountainking.entity;

import com.example.mountainking.Config;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.tags.ItemTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.block.entity.BellBlockEntity;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.phys.Vec3;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * IL RE DELLA MONTAGNA
 *
 * - E' CIECO: non usa mai la vista. Sceglie i bersagli solo in base ai rumori che sente (vedi listen()).
 *   Corsa, salti, colpi, scavo, danni subiti = rumore forte. Camminare = rumore medio.
 *   Muoversi di soppiatto (shift) = silenzio, a meno che non sia a meno di 3 blocchi (lo "sente" col terreno).
 * - Una CAMPANA che suona lo attira, e quando arriva li' resta CONFUSO per diversi secondi.
 * - Il pelo folto ferma frecce e (in parte) spade; il fuoco invece lo ferisce di piu'.
 * - Se uccide un giocatore, vedi GameEvents: il cadavere diventa una LarvaEntity dormiente.
 */
public class MountainKingEntity extends Monster {

    private static final EntityDataAccessor<Boolean> DATA_CONFUSED =
            SynchedEntityData.defineId(MountainKingEntity.class, EntityDataSerializers.BOOLEAN);

    /** Entro questo raggio sente chiunque, anche se e' silenzioso. */
    private static final double TOUCH_RANGE = 3.0D;
    /** Per quanti tick continua a inseguire dopo l'ultimo rumore udito. */
    private static final int REACTION_TICKS = 12;

    /** Ultimo punto da cui ha sentito un rumore (null = nessun sospetto). */
    private Vec3 noisePos;
    /** true se quel rumore e' una campana (esca). */
    private boolean noiseIsLure;
    private int confusedTicks;
    private int lastHeardTick;
    private final Map<UUID, Vec3> lastPositions = new HashMap<>();

    public MountainKingEntity(EntityType<? extends MountainKingEntity> type, Level level) {
        super(type, level);
        this.xpReward = 60;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 240.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.27D)
                .add(Attributes.ATTACK_DAMAGE, 15.0D)
                .add(Attributes.ATTACK_KNOCKBACK, 1.2D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.85D)
                .add(Attributes.ARMOR, 14.0D)
                .add(Attributes.ARMOR_TOUGHNESS, 4.0D)
                .add(Attributes.FOLLOW_RANGE, 40.0D)
                .add(Attributes.STEP_HEIGHT, 1.6D);
    }

    /** Spawn naturale: poco frequente, anche di giorno (il peso si regola nel biome modifier JSON). */
    public static boolean checkKingSpawnRules(EntityType<MountainKingEntity> type, ServerLevelAccessor level,
                                              MobSpawnType spawnType, BlockPos pos, RandomSource random) {
        return Monster.checkAnyLightMonsterSpawnRules(type, level, spawnType, pos, random) && random.nextInt(3) == 0;
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(DATA_CONFUSED, false);
    }

    /** true quando e' disorientato da una campana (il modello scuote la testa piu' forte). */
    public boolean isConfused() {
        return this.entityData.get(DATA_CONFUSED);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new MeleeAttackGoal(this, 1.1D, true));
        this.goalSelector.addGoal(2, new ConfusedGoal());
        this.goalSelector.addGoal(3, new InvestigateNoiseGoal());
        this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.6D));
        this.goalSelector.addGoal(6, new RandomLookAroundGoal(this));
        // Nessun "target goal": essendo cieco, i bersagli li sceglie solo listen().
    }

    // ------------------------------------------------------------------ UDITO

    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        if (this.confusedTicks > 0) {
            this.confusedTicks--;
        }
        final boolean confused = this.confusedTicks > 0;
        if (confused != this.isConfused()) {
            this.entityData.set(DATA_CONFUSED, confused);
        }
        if (this.tickCount % 4 == 0) {
            this.listen();
        }
    }

    private void listen() {
        if (!(this.level() instanceof ServerLevel serverLevel)) {
            return;
        }
        final double range = Config.HEARING_RANGE.get();
        final boolean targetCreative = Config.TARGET_CREATIVE.get();

        // 1) Campane: un'esca sonora che richiama il Re lontano dai giocatori
        if (this.tickCount % 8 == 0) {
            Vec3 bell = this.findRingingBell(serverLevel, Config.BELL_RANGE.get());
            if (bell != null && !this.isFightingNearby()) {
                boolean fresh = this.noisePos == null || !this.noiseIsLure || this.noisePos.distanceToSqr(bell) > 1.0D;
                this.noisePos = bell;
                this.noiseIsLure = true;
                this.confusedTicks = 0;
                this.setTarget(null);
                if (fresh) {
                    this.playSound(SoundEvents.WARDEN_LISTENING, 2.0F, 0.6F);
                }
            }
        }

        // 2) Giocatori: li sente solo se fanno abbastanza rumore per la distanza a cui si trovano
        Player best = null;
        double bestMargin = -1.0D;
        for (Player p : serverLevel.getEntitiesOfClass(Player.class, this.getBoundingBox().inflate(range),
                pl -> pl.isAlive() && !pl.isSpectator() && (targetCreative || !pl.isCreative()))) {
            Vec3 prev = this.lastPositions.put(p.getUUID(), p.position());
            double dist = this.distanceTo(p);
            double loud = this.noiseRadius(p, prev);
            if (dist <= TOUCH_RANGE) {
                loud = Math.max(loud, dist + 1.0D);
            }
            if (this.confusedTicks > 0 && dist > 7.0D) {
                continue;   // confuso: ignora tutto cio' che non e' vicinissimo
            }
            double margin = loud - dist;
            if (margin >= 0.0D && margin >= bestMargin) {
                best = p;
                bestMargin = margin;
            }
        }
        if (this.lastPositions.size() > 32) {
            this.lastPositions.clear();
        }

        if (best != null) {
            if (this.getTarget() == null) {
                this.playSound(SoundEvents.WARDEN_ANGRY, 2.5F, 0.7F);
            }
            this.setTarget(best);
            this.lastHeardTick = this.tickCount;
            this.noisePos = best.position();
            this.noiseIsLure = false;
            this.confusedTicks = 0;
        } else if (this.getTarget() != null && this.tickCount - this.lastHeardTick > REACTION_TICKS) {
            // Silenzio: perde il bersaglio e va a controllare l'ultimo punto da cui ha sentito qualcosa
            this.noisePos = this.getTarget().position();
            this.noiseIsLure = false;
            this.setTarget(null);
        }
    }

    /** Quanto lontano (in blocchi) si sente il rumore che sta facendo il giocatore in questo momento. */
    private double noiseRadius(Player p, Vec3 prev) {
        double radius = 0.0D;
        if (prev != null) {
            double dx = p.getX() - prev.x;
            double dz = p.getZ() - prev.z;
            double moved = Math.sqrt(dx * dx + dz * dz);
            if (moved > 0.08D && moved < 6.0D) {          // si muove (e non si e' teletrasportato)
                if (p.isFallFlying()) {
                    radius = 8.0D;
                } else if (p.isSwimming()) {
                    radius = 16.0D;
                } else if (p.isSprinting()) {
                    radius = 26.0D;
                } else if (p.isShiftKeyDown()) {
                    radius = 0.0D;                        // di soppiatto: silenzio
                } else {
                    radius = 14.0D;
                }
                if (!p.onGround() && p.getY() - prev.y > 0.2D) {
                    radius = Math.max(radius, 20.0D);     // salto
                }
            }
        }
        if (p.swinging) {
            radius = Math.max(radius, 14.0D);             // colpi, scavo, piazzare blocchi
        }
        if (p.isUsingItem()) {
            radius = Math.max(radius, 7.0D);              // mangiare, tendere l'arco...
        }
        if (p.hurtTime > 0) {
            radius = Math.max(radius, 32.0D);             // un grido di dolore
        }
        return radius;
    }

    /** Cerca la campana che sta suonando piu' vicina (solo chunk gia' caricati). */
    private Vec3 findRingingBell(ServerLevel level, double range) {
        final int minCx = ((int) Math.floor(this.getX() - range)) >> 4;
        final int maxCx = ((int) Math.floor(this.getX() + range)) >> 4;
        final int minCz = ((int) Math.floor(this.getZ() - range)) >> 4;
        final int maxCz = ((int) Math.floor(this.getZ() + range)) >> 4;
        double best = range * range;
        Vec3 result = null;
        for (int cx = minCx; cx <= maxCx; cx++) {
            for (int cz = minCz; cz <= maxCz; cz++) {
                LevelChunk chunk = level.getChunkSource().getChunkNow(cx, cz);
                if (chunk == null) {
                    continue;
                }
                for (BlockEntity be : chunk.getBlockEntities().values()) {
                    if (be instanceof BellBlockEntity bell && bell.shaking && bell.ticks < 20) {
                        Vec3 center = Vec3.atCenterOf(be.getBlockPos());
                        double d = center.distanceToSqr(this.position());
                        if (d < best) {
                            best = d;
                            result = center;
                        }
                    }
                }
            }
        }
        return result;
    }

    private boolean isFightingNearby() {
        LivingEntity target = this.getTarget();
        return target != null && this.distanceToSqr(target) < 36.0D;
    }

    /** Colpito: "sente" da dove arriva il colpo. Con le frecce sa solo la direzione generale. */
    private void feelAttacker(LivingEntity culprit, DamageSource source) {
        if (culprit instanceof Player player && player.isCreative() && !Config.TARGET_CREATIVE.get()) {
            return;
        }
        final boolean melee = source.getDirectEntity() == culprit;
        Vec3 where = culprit.position();
        if (!melee) {
            where = where.add((this.random.nextDouble() - 0.5D) * 10.0D, 0.0D, (this.random.nextDouble() - 0.5D) * 10.0D);
        }
        this.noisePos = where;
        this.noiseIsLure = false;
        this.confusedTicks = 0;
        this.lastHeardTick = this.tickCount;
        if (melee || this.distanceToSqr(culprit) < 100.0D) {
            this.setTarget(culprit);
        }
    }

    private void arriveAtNoise() {
        final boolean lure = this.noiseIsLure;
        this.noisePos = null;
        this.noiseIsLure = false;
        this.getNavigation().stop();
        // dopo una campana resta confuso a lungo; dopo un rumore normale "annusa" solo un attimo
        this.confusedTicks = lure ? Config.CONFUSION_SECONDS.get() * 20 : 50;
        this.playSound(lure ? SoundEvents.WARDEN_LISTENING : SoundEvents.WARDEN_SNIFF, 2.0F, 0.6F);
    }

    // ------------------------------------------------------------------ COMBATTIMENTO

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (!this.level().isClientSide) {
            if (source.is(DamageTypeTags.IS_PROJECTILE)) {
                amount *= 0.2F;                       // il pelo folto ferma le frecce
                this.playSound(SoundEvents.WOOL_HIT, 1.0F, 0.7F);
            } else if (source.getDirectEntity() instanceof LivingEntity attacker
                    && attacker.getMainHandItem().is(ItemTags.SWORDS)) {
                amount *= 0.5F;                       // ...e smorza i colpi di spada
            }
            if (source.is(DamageTypeTags.IS_FIRE)) {
                amount *= 1.6F;                       // punto debole: e' tutto pelo secco
            }
        }
        final boolean hurt = super.hurt(source, amount);
        if (hurt && !this.level().isClientSide && source.getEntity() instanceof LivingEntity culprit) {
            this.feelAttacker(culprit, source);
        }
        return hurt;
    }

    @Override
    public boolean doHurtTarget(Entity target) {
        final boolean hit = super.doHurtTarget(target);
        if (hit) {
            this.playSound(SoundEvents.WARDEN_ATTACK_IMPACT, 1.5F, 0.8F);
            if (target instanceof LivingEntity living) {
                // le mani quasi umane afferrano la preda: lentezza
                living.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 80, 2), this);
            }
        }
        return hit;
    }

    // ------------------------------------------------------------------ EFFETTI

    @Override
    public void aiStep() {
        if (this.level().isClientSide && this.random.nextInt(5) == 0) {
            // bava viscosa che cola dal mento
            final double rad = Math.toRadians(this.yBodyRot);
            final double fx = -Math.sin(rad);
            final double fz = Math.cos(rad);
            this.level().addParticle(ParticleTypes.FALLING_HONEY,
                    this.getX() + fx * 1.5D + (this.random.nextDouble() - 0.5D) * 0.4D,
                    this.getY() + 3.1D,
                    this.getZ() + fz * 1.5D + (this.random.nextDouble() - 0.5D) * 0.4D,
                    0.0D, 0.0D, 0.0D);
        }
        super.aiStep();
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.WARDEN_AMBIENT;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.WARDEN_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.WARDEN_DEATH;
    }

    @Override
    protected void playStepSound(BlockPos pos, BlockState state) {
        this.playSound(SoundEvents.WARDEN_STEP, 1.2F, 0.6F);
    }

    // ------------------------------------------------------------------ OBIETTIVI (GOAL)

    /** Confuso: resta fermo e gira la testa a destra e a sinistra. */
    private class ConfusedGoal extends Goal {
        private int lookTimer;

        ConfusedGoal() {
            this.setFlags(EnumSet.of(Goal.Flag.MOVE, Goal.Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            return MountainKingEntity.this.confusedTicks > 0 && MountainKingEntity.this.getTarget() == null;
        }

        @Override
        public boolean canContinueToUse() {
            return this.canUse();
        }

        @Override
        public void start() {
            MountainKingEntity.this.getNavigation().stop();
            this.lookTimer = 0;
        }

        @Override
        public void tick() {
            final MountainKingEntity king = MountainKingEntity.this;
            if (--this.lookTimer <= 0) {
                this.lookTimer = 15 + king.random.nextInt(25);
                final double angle = king.random.nextDouble() * Math.PI * 2.0D;
                king.getLookControl().setLookAt(king.getX() + Math.cos(angle) * 6.0D,
                        king.getEyeY() + king.random.nextInt(3) - 1, king.getZ() + Math.sin(angle) * 6.0D);
                if (king.random.nextInt(3) == 0) {
                    king.playSound(SoundEvents.WARDEN_LISTENING, 1.5F, 0.7F);
                }
            }
        }
    }

    /** Va a controllare l'ultimo punto da cui ha sentito un rumore (o la campana che ha suonato). */
    private class InvestigateNoiseGoal extends Goal {
        private int repath;

        InvestigateNoiseGoal() {
            this.setFlags(EnumSet.of(Goal.Flag.MOVE));
        }

        @Override
        public boolean canUse() {
            final MountainKingEntity king = MountainKingEntity.this;
            return king.noisePos != null && king.getTarget() == null && king.confusedTicks <= 0;
        }

        @Override
        public boolean canContinueToUse() {
            return this.canUse();
        }

        @Override
        public void start() {
            this.repath = 0;
        }

        @Override
        public void tick() {
            final MountainKingEntity king = MountainKingEntity.this;
            final Vec3 pos = king.noisePos;
            if (pos == null) {
                return;
            }
            final double dx = pos.x - king.getX();
            final double dz = pos.z - king.getZ();
            if (dx * dx + dz * dz < 36.0D) {        // e' enorme: "arrivato" a 6 blocchi
                king.arriveAtNoise();
                return;
            }
            if (--this.repath <= 0) {
                this.repath = 10;
                king.getNavigation().moveTo(pos.x, pos.y, pos.z, king.noiseIsLure ? 1.25D : 1.0D);
            }
        }
    }
}
