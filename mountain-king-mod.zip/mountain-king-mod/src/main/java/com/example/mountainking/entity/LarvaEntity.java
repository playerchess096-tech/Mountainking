package com.example.mountainking.entity;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;

import java.util.EnumSet;

/**
 * LARVA DEL RE DELLA MONTAGNA
 *
 * Nasce quando il Re uccide un giocatore: il cadavere si trasforma in una bestia DORMIENTE
 * (giace a terra e si contorce, immobile). Passato il tempo di config (o se un giocatore si avvicina troppo)
 * si risveglia e va a caccia degli altri giocatori. Da dormiente e' indifesa: subisce il doppio dei danni.
 */
public class LarvaEntity extends Monster {

    private static final EntityDataAccessor<Boolean> DATA_DORMANT =
            SynchedEntityData.defineId(LarvaEntity.class, EntityDataSerializers.BOOLEAN);

    private int dormantTicks;

    public LarvaEntity(EntityType<? extends LarvaEntity> type, Level level) {
        super(type, level);
        this.xpReward = 20;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 45.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.38D)
                .add(Attributes.ATTACK_DAMAGE, 6.0D)
                .add(Attributes.ARMOR, 4.0D)
                .add(Attributes.FOLLOW_RANGE, 32.0D)
                .add(Attributes.STEP_HEIGHT, 1.0D);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(DATA_DORMANT, false);
    }

    public boolean isDormant() {
        return this.entityData.get(DATA_DORMANT);
    }

    /** Chiamato quando il Re uccide un giocatore: la Larva nasce dormiente al posto del cadavere. */
    public void startDormant(int ticks, String victimName) {
        this.dormantTicks = ticks;
        this.entityData.set(DATA_DORMANT, true);
        this.setCustomName(Component.translatable("entity.mountainking.larva_of", victimName));
    }

    private void awaken() {
        this.entityData.set(DATA_DORMANT, false);
        this.dormantTicks = 0;
        this.playSound(SoundEvents.RAVAGER_ROAR, 1.3F, 1.9F);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(0, new DormantGoal());
        this.goalSelector.addGoal(1, new MeleeAttackGoal(this, 1.25D, true));
        this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.9D));
        this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 10.0F));
        this.goalSelector.addGoal(7, new RandomLookAroundGoal(this));
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    @Override
    public void tick() {
        super.tick();
        if (!this.level().isClientSide && this.isDormant()) {
            this.setTarget(null);
            final boolean playerClose = !this.level().getEntitiesOfClass(Player.class,
                    this.getBoundingBox().inflate(2.5D), p -> p.isAlive() && !p.isSpectator()).isEmpty();
            if (--this.dormantTicks <= 0 || playerClose) {
                this.awaken();
            }
        }
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (this.isDormant()) {
            final boolean hurt = super.hurt(source, amount * 2.0F);     // indifesa mentre dorme
            if (hurt && this.isAlive() && !this.level().isClientSide) {
                this.awaken();                                           // se sopravvive si sveglia furiosa
            }
            return hurt;
        }
        return super.hurt(source, amount);
    }

    @Override
    public void aiStep() {
        super.aiStep();
        if (this.level().isClientSide && this.isDormant() && this.random.nextInt(4) == 0) {
            this.level().addParticle(ParticleTypes.SMOKE, this.getRandomX(0.5D), this.getY() + 0.2D,
                    this.getRandomZ(0.5D), 0.0D, 0.02D, 0.0D);
        }
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putBoolean("Dormant", this.isDormant());
        tag.putInt("DormantTicks", this.dormantTicks);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        this.entityData.set(DATA_DORMANT, tag.getBoolean("Dormant"));
        this.dormantTicks = tag.getInt("DormantTicks");
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return this.isDormant() ? null : SoundEvents.SILVERFISH_AMBIENT;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.SILVERFISH_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.SILVERFISH_DEATH;
    }

    @Override
    protected void playStepSound(BlockPos pos, BlockState state) {
        this.playSound(SoundEvents.SILVERFISH_STEP, 0.15F, 1.0F);
    }

    /** Da dormiente non si muove e non guarda: blocca i comportamenti con priorita' piu' bassa. */
    private class DormantGoal extends Goal {
        DormantGoal() {
            this.setFlags(EnumSet.of(Goal.Flag.MOVE, Goal.Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            return LarvaEntity.this.isDormant();
        }

        @Override
        public boolean canContinueToUse() {
            return LarvaEntity.this.isDormant();
        }

        @Override
        public void start() {
            LarvaEntity.this.getNavigation().stop();
        }

        @Override
        public void tick() {
            LarvaEntity.this.getNavigation().stop();
            LarvaEntity.this.setZza(0.0F);
        }
    }
}
