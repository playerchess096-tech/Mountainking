package com.example.mountainking.client;

import com.example.mountainking.MountainKingMod;
import com.example.mountainking.entity.MountainKingEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class MountainKingRenderer extends MobRenderer<MountainKingEntity, MountainKingModel<MountainKingEntity>> {

    private static final ResourceLocation TEXTURE =
            ResourceLocation.fromNamespaceAndPath(MountainKingMod.MODID, "textures/entity/mountain_king.png");

    public MountainKingRenderer(EntityRendererProvider.Context context) {
        super(context, new MountainKingModel<>(context.bakeLayer(MountainKingModel.LAYER_LOCATION)), 1.6F);
        this.addLayer(new KingEyesLayer<>(this));   // cinque occhi bianco latte che brillano al buio
        this.addLayer(new WormsLayer<>(this));      // forme simili a vermi che si muovono sotto la pelle
    }

    @Override
    public ResourceLocation getTextureLocation(MountainKingEntity entity) {
        return TEXTURE;
    }
}
