package com.example.mountainking.registry;

import com.example.mountainking.MountainKingMod;
import com.example.mountainking.entity.LarvaEntity;
import com.example.mountainking.entity.MountainKingEntity;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(Registries.ENTITY_TYPE, MountainKingMod.MODID);

    /** Alto 4,4 blocchi (il modello arriva a circa 4,3). */
    public static final DeferredHolder<EntityType<?>, EntityType<MountainKingEntity>> MOUNTAIN_KING =
            ENTITIES.register("mountain_king", () -> EntityType.Builder
                    .of(MountainKingEntity::new, MobCategory.MONSTER)
                    .sized(1.9F, 4.4F)
                    .clientTrackingRange(10)
                    .build("mountain_king"));

    /** Versione in miniatura (scala 0,3 nel renderer). */
    public static final DeferredHolder<EntityType<?>, EntityType<LarvaEntity>> LARVA =
            ENTITIES.register("larva", () -> EntityType.Builder
                    .of(LarvaEntity::new, MobCategory.MONSTER)
                    .sized(0.6F, 1.35F)
                    .clientTrackingRange(8)
                    .build("larva"));
}
