package com.example.mountainking.client;

import com.example.mountainking.MountainKingMod;
import com.example.mountainking.entity.LarvaEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

/** La Larva e' il Re della Montagna in miniatura: stesso modello e stessa texture, scala 0,3. */
public class LarvaRenderer extends MobRenderer<LarvaEntity, MountainKingModel<LarvaEntity>> {

    private static final ResourceLocation TEXTURE =
            ResourceLocation.fromNamespaceAndPath(MountainKingMod.MODID, "textures/entity/mountain_king.png");

    public LarvaRenderer(EntityRendererProvider.Context context) {
        super(context, new MountainKingModel<>(context.bakeLayer(MountainKingModel.LAYER_LOCATION)), 0.5F);
        this.addLayer(new KingEyesLayer<>(this));
        this.addLayer(new WormsLayer<>(this));
    }

    @Override
    protected void scale(LarvaEntity larva, PoseStack poseStack, float partialTick) {
        poseStack.scale(0.3F, 0.3F, 0.3F);
    }

    @Override
    public ResourceLocation getTextureLocation(LarvaEntity entity) {
        return TEXTURE;
    }
}
